package com.capgemini.contact.service;

import java.util.regex.Pattern;

import com.capgemini.apply.dao.ApplyDao;
import com.capgemini.apply.dao.ApplyDaoImpl;
import com.capgemini.contact.bean.ApplicationBean;
import com.capgemini.contact.exception.ApplicationException;

public class ApplyServiceImpl implements ApplyService {

	ApplyDao appDao;
	public ApplyServiceImpl() {
		
		appDao = new ApplyDaoImpl();
	}
	
	@Override
	public int addApplicantDetails(ApplicationBean applicant)
			throws ApplicationException {
		
		return appDao.addApplicantDetails(applicant);
	}

	@Override
	public ApplicationBean getApplicationDetails(long applicationID)
			throws ApplicationException {
		
		return appDao.getApplicationDetails(applicationID);
	}

	@Override
	public boolean isValidApplicatnt(ApplicationBean applicant)
			throws ApplicationException {
		
		String fn = applicant.getfName();
		String ln = applicant.getlName();
		long ph = applicant.getContactNo();
		String str = applicant.getStream();
		float agg = applicant.getAggregate();
		String mail = applicant.getEmail();
		
		String phnRegex = "[7-9][0-9]{9}";
		String mailRegex = "[A-Za-z0-9+_.-]+@(.+)$";
		String nameRegex = "[A-Z][a-z]+";
		String str1 = "Computer Science";
		String str2 = "Information Technology";
		
		//System.out.println(!str.equals("Information Technology" + "Computer Science"));
		//System.out.println(str);
		if( !Pattern.matches(nameRegex, fn) ) {
			throw new ApplicationException("First name starts with captital letter (eg.Vasu)");
			
		}
		else if( !Pattern.matches(nameRegex, ln) ) {
			throw new ApplicationException("Last name starts with captital letter (eg.Sharma)");
		}
		else if( !Pattern.matches(phnRegex,new  Long(ph).toString()) ) {
			throw new ApplicationException("Contact number should be a 10 digit valid number");
		}
		else if( !Pattern.matches(mailRegex, mail) ) {
			throw new ApplicationException("Please enter a valid mail id");
		}
		else if( !(str.equals("Information Technology") ) &&  !(str.equals("Computer Science")) ) {
			throw new ApplicationException("Stream should be either Computer Science or Information Technology");
		}
		else if( agg < 0) {
			throw new ApplicationException("Aggregate should be positive real number");
		}
		else  {
			return true;
		}
		
		
	}

}
