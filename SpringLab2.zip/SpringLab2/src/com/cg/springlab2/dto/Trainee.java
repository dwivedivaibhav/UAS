package com.cg.springlab2.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;


@Entity
@Table(name="traineemanagement")
public class Trainee 
{
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE , generator="tra_seq")  
	@SequenceGenerator(name="tra_seq" , sequenceName="tra_seq_tid")  
	@Column(name="tra_id")
	private Integer traId;
	
	@Column(name="tra_name")
	@NotEmpty(message="Name Should Not Be Empty")
	private String traName;
	
	@Column(name="tra_loc")
	private String traLocation;
	
	@Column(name="tra_domain")
	private String traDomain;
	
	
	public Integer getTraId() {
		return traId;
	}
	
	public void setTraId(Integer traId) {
		this.traId = traId;
	}
	public String getTraName() {
		return traName;
	}
	public void setTraName(String traName) {
		this.traName = traName;
	}
	public String getTraLocation() {
		return traLocation;
	}
	public void setTraLocation(String traLocation) {
		this.traLocation = traLocation;
	}
	public String getTraDomain() {
		return traDomain;
	}
	public void setTraDomain(String traDomain) {
		this.traDomain = traDomain;
	}
	
	

}
