package com.cg.springlab2.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springlab2.dao.ITraineeDao;
import com.cg.springlab2.dto.Trainee;


@Service("traineeservice")
@Transactional
public class TraineeServiceImpl implements ITraineeService
{

	@Autowired
	ITraineeDao traineedao;
	
	@Override
	public int addTraineeData(Trainee tra) 
	{
		
		return traineedao.addTraineeData(tra);
	}

	@Override
	public void deleteTrainee(int traId) 
	{
		traineedao.deleteTrainee(traId);
		
	}

	@Override
	public List<Trainee> viewAll() {
		
		return traineedao.viewAll();
	}

	@Override
	public List<Trainee> searchTrainee(int traId) {
		return traineedao.searchTrainee(traId);
		
	}

}
