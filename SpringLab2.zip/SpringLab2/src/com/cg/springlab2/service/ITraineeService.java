package com.cg.springlab2.service;

import com.cg.springlab2.dto.Trainee;


public interface ITraineeService 
{
	public int addTraineeData(Trainee tra);

	public void deleteTrainee(int traId);
}
