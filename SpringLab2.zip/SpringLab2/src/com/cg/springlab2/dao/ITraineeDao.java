package com.cg.springlab2.dao;

import com.cg.springlab2.dto.Trainee;

public interface ITraineeDao 
{
	public int addTraineeData(Trainee tra);
	public void deleteTrainee(int traId);
}
