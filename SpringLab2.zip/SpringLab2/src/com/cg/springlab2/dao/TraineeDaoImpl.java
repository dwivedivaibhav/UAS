package com.cg.springlab2.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springlab2.dto.Trainee;


@Repository("traineedao")
public class TraineeDaoImpl implements ITraineeDao
{
	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public int addTraineeData(Trainee tra)
	{
		entitymanager.persist(tra);
		entitymanager.flush();
		
		return tra.getTraId();
	}

	@Override
	public void deleteTrainee(int traId) 
	{
		
		Query queryOne=entitymanager.createQuery("DELETE FROM Trainee WHERE traId=:tid");  
		//tid Is the link("key","value")
		queryOne.setParameter("tid", traId);    
		queryOne.executeUpdate();
		
	}

}
