package com.capgemini.trainee.dao;

import java.util.List;

import com.capgemini.trainee.bean.Trainee;

public interface ITraineeDao {
	public Trainee addTrainee(Trainee trainee);
	public void deleteTrainee(String trainee);
	public Trainee modifyTrainee(Trainee trainee);
	public Trainee retrieveTraineeDetails(int traineeId);
	public List<Trainee> getAllTraineesDetails();
}
